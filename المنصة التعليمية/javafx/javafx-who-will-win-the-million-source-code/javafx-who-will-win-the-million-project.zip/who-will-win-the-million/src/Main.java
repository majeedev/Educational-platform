import java.util.Locale;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Main extends Application implements ScreenBounds {

    // لأننا سنعتبر كل واحد منهم كصفحة في التطبيق Pane لأنه سيمثل نافذة التطبيق, و 4 كائنات من الكلاس STAGE هنا قمنا بإنشاء كائن من الكلاس
    // لتسهيل الوصول إليهم و لعدم الحاجة إلى إنشاء كائن منهم كلما أردنا التنقل بين الصفحات و هذا الأمر يجعل حجم البرنامج أصغر في الذاكرة static و قمنا بتعريفهم كـ
    static Stage STAGE;
    static Pane PANE_MENU = new MenuPane();
    static Pane PANE_ABOUT = new AboutPane();
    static Pane PANE_RESULT = new ResultPane();
    static Pane PANE_GAME = new GamePane();

    @Override
    public void start(Stage stage) {

        // هنا قمنا بإنشاء النافذة و جعلناها تملئ شاشة المستخدم, غير قابلة للتصغير, و وضعنا أيقونة لها, كما أننا وضعنا لها عنوان
        STAGE = stage;
        STAGE.setFullScreen(true);
        STAGE.setResizable(false);
        STAGE.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
        STAGE.getIcons().add(new Image(Main.class.getResourceAsStream("res/images/icon.png")));
        STAGE.setTitle("من سيربح المليون - أسئلة إسلامية");

        // STAGE ثم مررناه للكائن ( PANE_MENU وضعنا فيه الحاوية ) Scene هنا قمنا بإنشاء كائن من الكلاس
        // هي أول حاوية ( أي أول صفحة ) يتم عرضها عند تشغيل اللعبة PANE_MENU هكذا ستكون الحاوية 
        STAGE.setScene(new Scene(PANE_MENU));

        // هنا قمنا بإظهار نافذة اللعبة
        STAGE.show();

    }

    // هذه الدالة قمنا ببنائها لتعيين الصورة التي نريد وضعها كخلفية لأي حاوية ( و نقصد صفحة ) نعرضها في اللعبة, فعلياً ترجع لنا الصورة فقط
    public static Background GetBGImage() {
        BackgroundImage myBI = new BackgroundImage(
                new Image("res/images/black-wallpaper.jpg"),
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);

        return new Background(myBI);
    }

    public static void main(String[] args) {
        Locale.setDefault(new Locale("ar"));
        launch(args);
    }

}
