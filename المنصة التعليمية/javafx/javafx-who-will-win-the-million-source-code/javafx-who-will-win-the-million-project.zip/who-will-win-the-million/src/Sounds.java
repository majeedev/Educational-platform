import javafx.scene.media.AudioClip;

// وضعنا فيه 5 دوال, كل دالة منهم تعطينا صوت معين عند إستدعاءها Sounds الكلاس
public class Sounds {
    
    // لتمثلها و لنستطيع تشغيلها من خلالها AudioClip الملفات الصوتية الموضوعة في المشروع قمنا بإنشاء كائنات من الكلاس
    AudioClip audio_1 = new AudioClip(getClass().getResource("res/sounds/general-click.wav").toString());
    AudioClip audio_2 = new AudioClip(getClass().getResource("res/sounds/playing-click.wav").toString());
    AudioClip audio_3 = new AudioClip(getClass().getResource("res/sounds/intro.MP3").toString());
    AudioClip audio_4 = new AudioClip(getClass().getResource("res/sounds/clock-tick.wav").toString());
    AudioClip audio_5 = new AudioClip(getClass().getResource("res/sounds/win-sound.mp3").toString());
    
    public void clickSound() {
        audio_1.play();
    }
    
    public void ClickOnWrongAnswerSound() {
        audio_2.play();
    }
    
    public void ClickOnCorrectAnswerSound() {
        audio_5.play();
    }
    
    public void introSound() {
        audio_3.play();
    }
    
    public void clockTickSound() {
        audio_4.play();
    }
    
}
