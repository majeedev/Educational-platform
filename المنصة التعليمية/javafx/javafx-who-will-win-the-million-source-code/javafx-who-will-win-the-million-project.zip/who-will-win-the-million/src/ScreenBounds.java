import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;

// وضعنا في هذا الإنترفيس, المعلومات الأساسية و المشتركة التي يجب أن تتوفر في كل حاوية تمثل صفحة في اللعبة
public interface ScreenBounds {
    
    Screen SCREEN = Screen.getPrimary();
    Rectangle2D BOUNDS = SCREEN.getVisualBounds();

    double WIDTH = BOUNDS.getMaxX();
    double HEIGHT = BOUNDS.getMaxY();
    
}
