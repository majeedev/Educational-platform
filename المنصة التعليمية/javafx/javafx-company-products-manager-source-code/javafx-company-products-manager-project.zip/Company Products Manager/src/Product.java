import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;

// ليمثل أي منتج يمكن عرضه في الجدول و يمكن تخزينه في قاعدة البيانات أيضاً Product قمنا ببناء الكلاس
public class Product {
 
    // هنا قمنا بتحديد المعلومات الأساسية التي يمكن أن يحتويها كل منتج
    SimpleIntegerProperty id;
    SimpleStringProperty name;
    SimpleDoubleProperty price;
    SimpleStringProperty addedDate;
    SimpleStringProperty imageUrl;
 
    // هنا قمنا بإنشاء كونستركتور إفتراضي لتحديد القيم الأولية التي نريد وضعها لأي منتج يتم إنشاؤه
    public Product() {
        this.id = new SimpleIntegerProperty(0);
        this.name = new SimpleStringProperty("");
        this.price = new SimpleDoubleProperty(0.0);
        this.addedDate = new SimpleStringProperty("");
        this.imageUrl = new SimpleStringProperty("");
    }
 
    // هنا قمنا بإنشاء كونستركتور ثاني يمكن استخدامه لتحديد القيم الأولية التي نريد تمريرها لأي منتج لحظة إنشاؤه
    public Product(int id, String name, double price, String addedDate, String imageUrl) {
        this.id = new SimpleIntegerProperty(0);
        this.name = new SimpleStringProperty(name);
        this.price = new SimpleDoubleProperty(price);
        this.addedDate = new SimpleStringProperty(addedDate);
        this.imageUrl = new SimpleStringProperty(imageUrl);
    }
    

    // لكل خاصية وضعناها في الكلاس مع الإشارة إلى أن بناء هذا الدوال Getter و Setter هنا قمنا ببناء دوال
    // TableView هو أمر إجباري و يجب فعله من لكي نتمكن لاحقاً من عرض الكائنات التي ننشئها من هذا الكلاس بداخل

    public int getId() {
        return id.getValue();
    }
 
    public void setId(int id) {
        this.id = new SimpleIntegerProperty(id);
    }
 
    public String getName() {
        return name.getValue();
    }
 
    public void setName(String name) {
        this.name = new SimpleStringProperty(name);
    }
 
    public double getPrice() {
        return price.getValue();
    }
 
    public void setPrice(double price) {
        this.price = new SimpleDoubleProperty(price);
    }
 
    public String getAddedDate() {
        return addedDate.getValue();
    }
 
    public void setAddedDate(String addedDate) {
        this.addedDate = new SimpleStringProperty(addedDate);
    }
     
    public String getImageUrl() {
        return imageUrl.getValue();
    }
 
    public void setImageUrl(String imageUrl) {
        this.imageUrl = new SimpleStringProperty(imageUrl);
    }
 
}
