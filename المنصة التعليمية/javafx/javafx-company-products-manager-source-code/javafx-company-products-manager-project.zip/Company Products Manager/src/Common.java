import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

// نقوم ببناءها في المشروع static قمنا ببنائه خصيصاً لوضع أي دوال Common الكلاس
// حتى نحصل على الثوابت الموجودة فيه و التي سنحتاجها في الدوال DBInfo جعلناه ينفذ الإنترفيس
public class Common implements DBInfo {
    
    // و التي سنستخدمها كلما أردنا الإتصال بقاعدة البيانات getConnection() هنا قمنا ببناء الدالة
    public static Connection getConnection()
    {
        Connection con;

        try {
            // DBInfo معلومات الإتصال بقاعدة البيانات قمنا بجلبها من الإنترفيس
            con = DriverManager.getConnection(DB_NAME_WITH_ENCODING, USER, PASSWORD);
            return con;
        }
        catch (SQLException ex) {
            return null;
        }
    }
    
    // الدالة التالية نستخدمها لتوليد إسم فريد لكل صورة يضيفها المستخدم في التطبيق
    public static String generateImagePath(File selectedFile)
    {
        // date هنا قمنا بإنشاء تاريخ و وضعناه في الكائن
        java.util.Date date = new java.util.Date();
 
        // إفتراضياً Date التي يستخدمها الكلاس format جديدة لإظهار الوقت و لكننا إستخدمنا الـ format هنا قمنا بإنشاء
        SimpleDateFormat sdf = new SimpleDateFormat("Y-M-d-hh-mm-ss");
        
        // لأننا بحاجة لمعرفة إمتداد أي صورة سنقوم بتخزينها fileExtension في المتغير selectedFile هنا قمنا بتخزين إمتداد الملف الذي يشير إليه الكائن 
        String fileExtension = selectedFile.getName().substring(selectedFile.getName().lastIndexOf("."));
 
        // fileExtension إمتداد الملف أو الصورة التي تم تخزينها في المتغير + date في النهاية سترجع الدالة إسم مكون من توقيت جهاز المستخدم الحالي المخزن في الكائن
        return UPLOADED_FILE_PATH + sdf.format(date) + fileExtension;
    }
    
    // الدالة التالية نستخدمها لحفظ أي صورة يضعها المستخدم لمنتج على حاسوبه
    public static String saveSelectedImage(File selectedFile)
    {
        // createImagePath و من ثم سيتم تخزينه في المتغير generateImagePath() مسار الصورة التي سيتم تخزينها, سيتم إنشاؤه بواسطة الدالة
        String createImagePath = Common.generateImagePath(selectedFile);
        try {
            // يمثل الصورة التي إختارها المستخدم FileInputStream هنا قمنا بإنشاء كائن من الكلاس
            FileInputStream in = new FileInputStream(selectedFile);

            // يمثل النسخة التي سننشئها من الصورة التي اختارها المستخدم FileOutputStream هنا قمنا بإنشاء كائن من الكلاس
            FileOutputStream out = new FileOutputStream(createImagePath);
            
            // out و تخزينه في نسخة الصورة الجديدة التي يمثلها الكائن in هنا قمنا بقراءة محتوى الصورة التي اختارها المستخدم حرفاً حرفاً من الكائن
            int c;
            while ((c = in.read()) != -1) {
                out.write(c);
            }

            // هنا قمنا بإغلاق كلا الملفين في الذاكرة لأنه لم يعد هناك حاجة لهما
            in.close();
            out.close();
        }
        catch(Exception e) {}
        
        // هنا قمنا بإرجاع مسار النسخة الجديدة التي تم إنشاؤها من الصورة
        return createImagePath;
    }
    
    // filePath الدالة التالية نستخدمها لحذف أي صورة تم إضافتها سابقاً بناءاً على المسار الموجودة فيه و الذي نمرره مكان الباراميتر
    public static void deleteImage(String filePath)
    {
        try {
            File imageToDelete = new File(filePath);
            imageToDelete.delete();
        }
        catch(Exception e) {}
    }
    
}
