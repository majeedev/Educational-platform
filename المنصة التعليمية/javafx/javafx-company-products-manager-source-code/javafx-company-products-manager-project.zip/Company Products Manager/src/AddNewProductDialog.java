import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

// من أجل إضافة منتج جديد ( Add New ) يمثل النافذة المنبثقة التي سنظهرها عند النقر على الزر AddNewProductDialog الكلاس
// لأننا سنظهره كنافذة منبثقة مخصصة ( أي نحن من يبنيها ) أمام المستخدم Dialog جعلناه يرث من الكلاس
// ليحصل على المعلومات الضرورية التي نحتاجها للإتصال بخادم قاعدة البيانات DBInfo و جعلناه ينفذ الإنترفيس
public class AddNewProductDialog extends Dialog implements DBInfo {

    // هنا قمنا بإنشاء جميع الأشياء التي سنضعها في النافذة
    Pane pane = new Pane();
    Label nameLabel = new Label("Name");
    Label productImage = new Label("No image Selected");
    Label priceLabel = new Label("Price ( $ )");
    TextField nameField = new TextField();
    TextField priceField = new TextField();
    Button chooseImageButton = new Button("choose Image", new ImageView(new Image(getClass().getResourceAsStream("/images/add-image.png"))));
    Button addButton = new Button("Add Product", new ImageView(new Image(getClass().getResourceAsStream("/images/add-product.png"))));

    // مما يجعلنا قادرين على تمرير البيانات التي نضيفها بشكل مباشر في الجدول table الذي وضعناه للكائن data هذا الكائن سنستخدمه للوصول إلى الكائن
    ObservableList data;

    // لأننا سنستخدمه لعرض أي خطأ أو معلومة أما المستخدم بداخل نافذة منبثقة صغيرة بشكل مختصر SpecialAlert هنا قمنا بإنشاء كائن من الكلاس
    SpecialAlert alert = new SpecialAlert();
    
    // سنستخدمه لتخزين أي صورة يتم وضعها للمنتج بشكل مؤقت selectedFile الكائن
    File selectedFile = null;

    // AddNewProductDialog هذا كونستركتور الكلاس
    public AddNewProductDialog(ObservableList data)
    {
        // AllProductsPane الذي سيستعمله هذا الكائن (أي النافذة المنبثقة) هو نفسه الذي نمرره له من الكلاس data هنا قلنا أن الكائن
        // و هكذا فإن أي منتج سيتم إضافته في النافذة المنبثقة, سيتم عرضه بشكل مباشر في الجدول الموضوع في النافذة الأساسية في البرنامج
        this.data = data;

        // هنا قمنا بتحديد حجم كل شيء سيتم إضافته في النافذة المنبثقة
        pane.setPrefSize(610, 390);
        productImage.setPrefSize(224, 224);
        nameLabel.setPrefSize(80, 40);
        nameField.setPrefSize(270, 40);
        priceLabel.setPrefSize(80, 40);
        priceField.setPrefSize(270, 40);
        chooseImageButton.setPrefSize(274, 45);
        addButton.setPrefSize(538, 60);

        // هنا قمنا بتحديد مكان ظهور كل شيء سيتم إضافته في النافذة المنبثقة
        productImage.setTranslateX(36);
        productImage.setTranslateY(40);
        nameLabel.setTranslateX(300);
        nameLabel.setTranslateY(30);
        nameField.setTranslateX(300);
        nameField.setTranslateY(70);
        priceLabel.setTranslateX(300);
        priceLabel.setTranslateY(120);
        priceField.setTranslateX(300);
        priceField.setTranslateY(160);
        chooseImageButton.setTranslateX(298);
        chooseImageButton.setTranslateY(220);
        addButton.setTranslateX(34);
        addButton.setTranslateY(310);

        // هنا قمنا بتحديد خصائص الأشياء التي سيتم إضافتها في النافذة المنبثقة
        chooseImageButton.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        addButton.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        nameField.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        priceLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        priceField.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        productImage.setStyle("-fx-border-color: lightgray; -fx-border-width: 2;");
        nameField.setStyle("-fx-border-color: lightgray; -fx-border-width: 2;");
        priceField.setStyle("-fx-border-color: lightgray; -fx-border-width: 2;");
        addButton.setStyle("-fx-background-color: #444; -fx-text-fill:white; -fx-cursor: hand;");
        productImage.setAlignment(Pos.CENTER);

        // الذي يمثل حاوية النافذة المنبثقة pane هنا قمنا بإضافة جميع الأشياء التي قمنا بإنشائها في الكائن
        pane.getChildren().add(productImage);
        pane.getChildren().add(chooseImageButton);
        pane.getChildren().add(nameLabel);
        pane.getChildren().add(priceLabel);
        pane.getChildren().add(nameField);
        pane.getChildren().add(priceField);
        pane.getChildren().add(addButton);

        // الأربع أسطر التالية, وضعناه من أجل جعل زر خروج النافذة المنبثقة يعمل بشكل صحيح
        this.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        Node closeButton = this.getDialogPane().lookupButton(ButtonType.CLOSE);
        closeButton.managedProperty().bind(closeButton.visibleProperty());
        closeButton.setVisible(false);

        // هنا وضعنا عنوان للنافذة المنبثقة
        this.setTitle("Add New Product");
        
        // في النافذة المنبثقة حتى يظهر محتواها بداخلها pane هنا أضقنا الحاوية
        this.getDialogPane().setContent(pane);

        // nameField هنا كأننا قمنا بالنقر بواسطة الفأرة بدخل الكائن
        nameField.requestFocus();

        // chooseImage() سيتم استدعاء الدالة chooseImageButton هنا قمنا بتحديد أنه عند النقر على الزر الذي يمثله الكائن
        chooseImageButton.setOnAction(Action -> {
            chooseImage();
        });

        // insertProduct() سيتم استدعاء الدالة addButton هنا قمنا بتحديد أنه عند النقر على الزر الذي يمثله الكائن
        addButton.setOnAction(Action -> {
            insertProduct();
        });
    }
    
    // الدالة التالية سنستخدمها لجعل النافذة المنبثقة خالية من أي قيم إفتراضية
    private void resetWindow()
    {
        nameField.setText("");
        priceField.setText("");
        productImage.setText("No image selected");
        productImage.setGraphic(null);
        selectedFile = null;
        nameField.requestFocus();
    }

    // الدالة التالية سنستخدمها لإظهار و إخفاء النافذة المنبثقة
    public void display(boolean value)
    {
        // سيتم إظهار النافذة المنبثقة مع مسح أي قيم موضوعة فيها سابقاً value للباراميتر true إذا قمنا بتمرير القيمة
        if(value == true) {
            resetWindow();
            this.showAndWait();
        }
        // سيتم إخفاء النافذة المنبثقة value للباراميتر false إذا قمنا بتمرير القيمة
        else {
            this.hide();
        }
    }

    // الدالة التالية سنستخدمها لفحص القيم التي أدخلها المستخدم في الحقول للتأكد من صحتها قبل إضافة المنتج في قاعدة البيانات
    private boolean checkInputs()
    {
        if (nameField.getText().equals("") && priceField.getText().equals("")) {
            alert.show("Required fields are missing", "Name and Price fields cannot be empty!", AlertType.INFORMATION);
            return false;
        }
        else if (nameField.getText().equals("")) {
            alert.show("Required fields are missing", "Please enter product name", AlertType.INFORMATION);
            return false;
        }
        else if (priceField.getText().equals("")) {
            alert.show("Required fields are missing", "Please enter product price", AlertType.INFORMATION);
            return false;
        }

        try {
            Double.parseDouble(priceField.getText());
            return true;
        }
        catch (NumberFormatException ex) {
            alert.show("Error", "Price should be a decimal number (eg: 40, 10.5)", AlertType.ERROR);
            return false;
        }
    }

    // لجعل المستخدم قادر على إختيار صورة موجودة في حاسوبه chooseImage() قمنا ببناء الدالة
    // Choose Image سيتم إستدعاء هذه الدالة عندما يقوم المستخدم بالنقر على الزر
    private void chooseImage()
    {
        // و الذي سيمثل نافذة منبثقة لإختيار صورة من الجهاز FileChooser هنا قمنا بإنشاء كائن من الكلاس
        FileChooser fileChooser = new FileChooser();

        // هنا قمنا بتحديد نوع الصور التي يمكنك للمستخدم إختيارها من جهازه
        fileChooser.getExtensionFilters().add(
                new ExtensionFilter("Select a .JPG .PNG .GIF image", "*.jpg", "*.png", "*.gif")
        );

        // لتخزين الملف الذي قد يختاره المستخدم من الحاسوب selectedFile و قمنا بتجهيز الكائن showOpenDialog() بواسطة الدالة fileChooser هنا قمنا بإظهار الكائن
        selectedFile = fileChooser.showOpenDialog(null);

        // Open فهذا يعني أن المستخدم قام باختيار صورة من جهازه و من ثم نقر على الزر null لا تساوي selectedFile في حال كانت قيمة الكائن
        if (selectedFile != null) {
            // هنا قمنا بعرض الصورة التي تم اختيارها
            try {
                productImage.setText("");
                productImage.setGraphic(new ImageView(new Image(
                        selectedFile.toURI().toString(), 224, 224, true, true)));
            }
            catch (Exception e) {
                alert.show("Error", "Failed to add Image", AlertType.ERROR);
            }
        }

    }
    
    // قمنا ببناء الدالة التالية لحفظ جميع المعلومات التي أدخلها المستخدم في الحقول إضافةً إلى الصورة التي إختارها في قاعدة البيانات
    private void insertProduct()
    {
        // إذا تم التشييك على الحقول و كان لا يوجد أي خطأ أو نقص في المعلومات المطلوب إدخالها
        if (checkInputs()) {
            try {
                // سيتم الإتصال مع قاعدة البيانات
                Connection con = Common.getConnection();
                
                // إذا فشل الإتصال, سيتم إظهار نافذة منبثقة فيها رسالة تنبيه بذلك
                if(con == null) {
                    alert.show("Connection Error", "Failed to connect to database server", Alert.AlertType.ERROR);
                }

                // إذا نجح الإتصال, سيتم تجهيز الإستعلام الذي سيتم تنفيذه في قاعدة البيانات لحفظ المعلومات المدخلة في الحقول
                PreparedStatement ps;

                // إذا لم يقم المستخدم بوضع صورة للمنتج, سيتم تخزين فقط المعلومات التي أدخلها في الحقول
                if (selectedFile == null) {
                    ps = con.prepareStatement("INSERT INTO products(name, price, added_date) values(?,?,?)");
                }
                // إذا قام المستخدم بوضع صورة للمنتج, سيتم تخزين المعلومات التي أدخلها في الحقول مع الصورة التي إختارها أيضاً
                else {
                    String createImagePath = Common.saveSelectedImage(selectedFile);
            
                    ps = con.prepareStatement("INSERT INTO products(name, price, added_date, image_url) values(?,?,?,?)");
                    ps.setString(4, createImagePath);
                }

                ps.setString(1, nameField.getText());
                ps.setDouble(2, Double.valueOf(priceField.getText()));

                LocalDate todayLocalDate = LocalDate.now();
                Date sqlDate = Date.valueOf(todayLocalDate);

                // تاريخ إضافة المنتج سيتم تخزينه بشكل تلقائي
                ps.setDate(3, sqlDate);

                // في الأخير سيتم تنفيذ الإستعلام و إغلاق الإتصال مع قاعدة البيانات
                ps.executeUpdate();
                con.close();

                 // ل مسح جميع المعلومات التي أدخلها المستخدم في الحقول, حتى يتمكن من إدخال معلومات منتج جديد بسرعةresetWindow() ثم سيتم استدعاء
                resetWindow();

                viewProductInTheTable();
            }
            catch (Exception e) {
                alert.show("Error", e.getMessage(), AlertType.ERROR);
            }
        }

    }

    // و التي سنقوم باستدعائها كلما تم إضافة منتج جديد لإظهاره في الجدول viewProductsInTheTable() هنا قمنا ببناء الدالة
    private void viewProductInTheTable()
    {
        // products هنا قمنا بالإتصال بقاعدة البيانات و بتجهيز الإستعلام الذي سيجلب جميع قيم الجدول
        Connection con = Common.getConnection();
        String query = "SELECT * FROM products ORDER BY ID DESC LIMIT 1";

        // لتخزين نتيجة الإستعلام rs لتنفيذ الإستعلام, و الكائن st هنا قمنا بإنشاء الكائن
        Statement st;
        ResultSet rs;

        try {
            // rs هنا قمنا بتنفيذ الإستعلام و تخزين نتيجته في الكائن
            st = con.createStatement();
            rs = st.executeQuery(query);

            // في كل مرة rs لتخزين منتج واحد من المنتجات التي ستكون موجودة في الكائن product هنا قمنا بإنشاء الكائن
            rs.next();

            // product بيانات المنتج التي سيتم إرجاعها في كل مرة سيتم تخزينها بشكل مؤقت في الكائن
            Product product = new Product();
            product.setId(rs.getInt("id"));
            product.setName(rs.getString("name"));
            product.setPrice(Double.parseDouble(rs.getString("price")));
            product.setAddedDate(rs.getDate("added_date").toString());
            product.setImageUrl(rs.getString("image_url"));

            // productList كعنصر واحد في المصفوفة product في الأخير سيتم إضافة الكائن
            data.add(product);

            // هنا قمنا بإغلاق الإتصال مع قاعدة البيانات لأننا لم نعد بحاجة إليها
            con.close();
        }
        catch (SQLException e) {
            alert.show("Error", e.getMessage(), AlertType.ERROR);
        }

    }

}
