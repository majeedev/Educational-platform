import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) {

        // الذي يمثل الحاوية التي نريد عرضها في النافذة AllProductsPane هنا قمنا بإنشاء كائن من الكلاس
        AllProductsPane allProductsPane = new AllProductsPane();
        
        // scene في الكائن Root Node أي كأننا وضعناه كـ .scene مباشرةً في الكائن allProductsPane هنا قمنا بوضع الكائن
        Scene scene = new Scene(allProductsPane, 1070, 640);

        // هنا وضعنا عنوان للنافذة
        stage.setTitle("Company Products Manager");
        
        // أي وضعنا محتوى النافذة الذي قمنا بإنشائه للنافذة .stage في كائن الـ scene هنا وضعنا كائن الـ
        stage.setScene(scene);
        
        // هنا قمنا بإظهار النافذة
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
