import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

// لعرض أي نوافذ التنبيه في التطبيق بدون الحاجة إلى تكرار كود كبير SpecialAlert قمنا ببناء الكلاس
public class SpecialAlert {
    
    // يمثل أي نافذة منبثقة سنعرضها في التطبيق مهما كان نوعها alert هنا قمنا بإنشاء كائن من الكلاس
    Alert alert = new Alert(AlertType.NONE);
    
    // الدالة التالية قمنا ببنائها لتحديد كل المعلومات التي نريد تمريرها للنافذة المنبثقة عند إظهارها دفعةً واحدة
    public void show(String title, String message, AlertType alertType) {
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.setAlertType(alertType);
        alert.showAndWait();
    }
}
