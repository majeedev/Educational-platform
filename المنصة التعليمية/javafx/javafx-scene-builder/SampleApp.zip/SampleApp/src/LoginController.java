import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class LoginController implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        Alert alertInformation = new Alert(AlertType.INFORMATION);
        alertInformation.setHeaderText("First Alert using FXML");
        alertInformation.setContentText("This is just a test");
        alertInformation.showAndWait();
    }
    
}
